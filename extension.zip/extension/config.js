// extension/config.js — DO NOT COMMIT. Listed in .gitignore.
// Run `npm run generate-secret` at the repo root to create a new secret.
export const SERVER_URL = 'https://api.coldbase.live/api';
export const DASH_URL = 'https://coldbase.live';
export const REACH_SECRET = 'f824a42ea02d149b28f96141068bc71538e3321f18b2c4cc';
export const DEBUG = false;
